honeslibrary(tidyr)
library(readxl)
library(dplyr)
library(ggplot2)
library(stringr)
library(writexl)

df <- read_excel("DACC_Hackathon_Media_Habit_Survey.xlsx", sheet = 2)
dff <- read_excel("DACC_Hackathon_Panelists_Demogs.xlsx")

################################################################################

dff <- dff %>%
  mutate(ID = str_remove_all(ID, "Panel "))

# natural join of datasets to remove panelists that did not respond to the demographic survey
merged <- merge(x = dff, y = df, by = "ID", all = FALSE)

################################################################################

# Q6a: In the last 3 months, how frequently do you read Newspapers
# col v_291 / dupl1_v_222 

df1 <- select(df, dupl1_v_222)

q6a <- df1 %>% 
  count(dupl1_v_222) %>%
  rename(Response = dupl1_v_222, Count = n) %>%
  mutate(Response = as.factor(Response)) %>%
  mutate(Response = recode(Response, 
                           '1' = 'Daily',
                           '2' = '5-6 days a week',
                           '3' = '3-4 days a week',
                           '4' = '1-2 days a week',
                           '5' = 'A few times a month',
                           '6' = 'Less often',
                           '7' = 'Never'))

readers <- sum(head(q6a, n = 6)$Count) # People who actually read

ggplot(data = q6a, aes(x = Response, y = Count)) + 
  geom_bar(stat = 'identity', fill = "steelblue") + 
  labs(title = "In the last 3 months, how frequently do you read Newspapers")

################################################################################

# Q6b: How much time do you spend reading newspaper in a typical day of the week
# col V_292 / dupl1_v_223
# NA refers to people who don't read in q6a

df2 <- select(df, dupl1_v_223)

q6b <- df2 %>%
  count(dupl1_v_223) %>%
  rename(Response = dupl1_v_223, Count = n) %>%
  replace_na(list(Response = 'No response')) %>%
  mutate(Response = as.factor(Response)) %>%
  mutate(Response = recode(Response,
                            '1' = 'Less than 5 min',
                            '2' = '5-14 min',
                            '3' = '15-29 min',
                            '4' = '30-44 min',
                            '5' = '45-59 min',
                            '6' = '1-2 hrs',
                            '7' = '2-3 hrs',
                            '8' = '3-4 hrs',
                            '9' = '4 hrs or more'))

ggplot(data = q6b, aes(x = Response, y = Count)) + 
  geom_bar(stat = 'identity', fill = "steelblue") + 
  labs(title ="How much time do you spend reading newspaper in a typical day of the week")

################################################################################

# Q6c: In the last 3 months, what type of content in the newspaper have you read?
# cols v_293 - v_298 / v_1154, dupl1_v_229, v_777 - v_780

df3 <- select(df, v_1154, dupl1_v_229, v_777:v_780)

headers <- c('International News', 'Local News', 'Business News', 'Entertainment',
             'Sports', 'Others')
  
q6c <- df3 %>%
  drop_na %>% # dropped NA since not interested in people who dont read here
  setNames(headers) %>%
  pivot_longer(1:6, names_to = 'Type_of_news', values_to = 'Count') %>%
  group_by(Type_of_news) %>%
  summarise(Count = sum(Count))

q6c$Type_of_news <- factor(q6c$Type_of_news, level = q6c$Type_of_news)

ggplot(data = q6c, aes(x = Type_of_news, y = Count)) + 
  geom_bar(stat = 'identity', fill = "steelblue") + 
  labs(x = "Type of news",
   title = "In the last 3 months, what type of content in the newspaper have you read?") +
  geom_hline(yintercept = readers, linetype = "dashed", color = "red", size = 1.5)

################################################################################

# q7: Which of the following e-Wallet have you used in the past one year
# cols v_304 - v_311, v_312, v_333
# v_312 left out for the purpose of plotting (Name of other epay apps, majority invalid responses)

df4 <- select(df, v_304:v_311, v_333)

headers2 <- c('BigPay', 'Boost', 'FavePay', 'GrabPay', 'Razer Pay', 'Setel',
             'Touch \'N Go eWallet', 'Others', 'None')

q7 <- df4 %>% 
  setNames(headers2) %>%
  mutate_at(9, ~replace(., is.na(.), 0)) %>% # padded with 0 to remove NA
  pivot_longer(1:9, names_to = 'eWallet_Service', values_to = 'Count') %>%
  group_by(eWallet_Service) %>%
  summarise(Count = sum(Count))

q7$eWallet_Service <- factor(q7$eWallet_Service, levels = q7$eWallet_Service)

ggplot(data = q7, aes(x = eWallet_Service, y = Count)) + 
  geom_bar(stat = 'identity', fill = "steelblue") + 
  labs(x = "eWallet Service",
       title = "Which of the following e-Wallet have you used in the past one year")

df5 <- select(df, v_312) %>%
  drop_na() #notice that most responses are tidak pernah and thus not really valid 

################################################################################

# engineered columns

################################################################################

df_relevant <- df %>%
  select(ID, dupl1_v_222, dupl1_v_223, v_1154, dupl1_v_229, v_777:v_780, v_304:v_311, v_333) %>%
  mutate_at(3:9, ~replace(., is.na(.), 0)) %>%
  mutate_at(18, ~replace(., is.na(.), 1))

# q6
# Most people do not read newspaper (70%), those that do spent minimal time reading. 
# we will keep the frequency data

df_relevant <- df_relevant %>%
  mutate("Frequency of Reading Newspaper" = dupl1_v_222)
                              
newspaper_freq <- select(df_relevant, "Frequency of Reading Newspaper")
summary(newspaper_freq)

# For newspaper content, those that do not read recorded NA
# we will classify with an extra bin to account for people that do not read
# For those that read, we observe that local, international news and entertainment as the most read
# Biz, sports and others are minor compared to the above, so we bin those collaterally as 'others'

df_relevant <- df_relevant %>%
  mutate("Others" = if_else((v_777 == 1 | v_779 == 1 | v_780 ==1), 1, 0))

# We will assign the types using strings and concat the combination they read
# 1 - international news
# 2 - local news
# 3 - Entertainment
# 4 - others
# X - if they dont read the genre

df_relevant <- df_relevant %>%
  rowwise() %>%
  mutate("v_1154_2" = if_else((`v_1154` == 1), "1", "X")) %>%
  mutate("dupl1_v_229_2" = if_else((`dupl1_v_229` == 1), "2", "X")) %>%
  mutate("v_778_2" = if_else((`v_778` == 1), "3", "X")) %>%
  mutate("Others_2" = if_else((`Others` == 1), "4", "X"))

df_relevant <- df_relevant %>%
  mutate("Content Read" = if_else((`Frequency of Reading Newspaper` == 7), "XXXX", paste(v_1154_2, dupl1_v_229_2, v_778_2, Others_2,
                                                                sep = "")))

# q7
# Since majority of people either use touch'n'go eWallet or don't use eWallets at all (account for almost 95%),
# It makes sense to split the data into "Uses eWallet" and "Uses touch'n'go"

df_relevant <- df_relevant %>%
  mutate("Uses eWallet" = if_else(v_333 == 1, 0, 1)) %>%
  mutate("Uses Touch'N Go" = if_else(v_310 == 1, 1, 0))

# trim to keep relevant cols

df_engineered <- df_relevant %>%
  select(ID, "Frequency of Reading Newspaper", "Content Read" ,"Uses eWallet", "Uses Touch'N Go") %>%
  arrange(ID, desc())

test <- df_engineered %>%
  group_by(`Content Read`, `Frequency of Reading Newspaper`) %>%
  summarise(Count = n()) %>%
  arrange(Count)

test2 <- df_engineered %>%
  group_by(`Content Read`) %>%
  summarise(Count = n()) %>%
  arrange(Count)

# we observe that most people either dont read at all, read all 4 categories or
# only read local news.

################################################################################

# export to excel
write_xlsx(df_engineered,"engineered_6_7.xlsx")

################################################################################

# Additional insights

dff2 <- subset(dff, BMI != 'Not Available') %>%
  mutate(BMI = recode(BMI, 'Obese' = 'Obese + Overweight', 'Over Weight' = 'Obese + Overweight'))

# Most people stay in the north
dff2 %>%
  group_by(Location) %>%
  summarize(count = n()) %>%
  mutate(count = count/sum(count))

# Chinese respondents appear to be much healthier than the other races
dff3 <- dff2 %>% 
  group_by(BMI, Ethnicity) %>%
  summarise(count = n()) %>%
  group_by(Ethnicity) %>%
  mutate(freq = count/sum(count)) %>%
  arrange(Ethnicity)
  

ggplot(dff3, aes(fill=BMI, y=freq, x=Ethnicity)) + geom_bar(position = "dodge", stat="identity") +
  labs(y = "Frequency", title = "BMI by Ethnicity")


dff3 %>%
  group_by(Ethnicity) %>%
  summarise(BMI)

